#' Calculate Scatter Halfspace Depth
#'
#' Calculates the exact or approximate scatter halfspace (=Tukey)
#' depth (Chen et al., 2018; Paindaveine and Van Bever, 2018) of a matrix
#' with respect to a multivariate data set.
#'
#' @param X Data matrix of dimension \code{n}-times-\code{d}, where \code{n} is
#' the number of observations, \code{d} is the dimension.
#'
#' @param Sigma Matrix whose depth to compute. Must be a positive definite
#' matrix of size \code{d}-times-\code{d}. If not provided, the depth of the
#' unit \code{d}-dimensional matrix is computed.
#'
#' @param mu Location estimator for the data \code{X} used in the computation of
#' the scatter halfspace depth. Typical choices are the mean of the dataset
#' \code{colMeans(X)}, or the halfspace (Tukey) median
#' \code{TukeyRegion::TukeyMedian(X)$barycenter}. If not provided, the center is
#' taken to be the origin \code{rep(0,ncol(X))}.
#'
#' @param method Method for the computation. Can be one of the choices
#' \code{method="exact"} (default), \code{method="rdirections"} of randomly
#' thrown directions in the unit sphere, or \code{method="rpoints"} when
#' hyperplanes of \code{d-1} are passed only through a limited number
#' of \code{N} configurations. Method \code{"exact"} gives exact results.
#' Both methods \code{"rdirections"} and \code{"rpoints"} give approximate
#' results.
#'
#' @param N Number of randomly thrown directions for the approximate
#' computation of the depth. Ignored if \code{exact = TRUE}, by default if
#' \code{exact = FALSE} set to \code{1e4}.
#'
#' @param EPS Numerical epsilon, safeguard for flopping errors. By default set 
#' to \code{EPS = 1e-14}.
#'
#' @param vrs Version of the algorhitm to be used. The program is prepared in
#' two versions: i) \code{vrs="C"} calls the \code{C++} version of the 
#' algorithm, programmed within the \code{RCppArmadillo} framework for
#' manipulating matrices, this should be the fastest version. Programmed
#' for dimension \code{d<=5}. ii) \code{vrs="R"}
#' calls the \code{R} version, valid for any dimension \code{d>=1}. All
#' versions give the same results, save for numerical errors caused by the
#' different architecture in \code{C++} and \code{R}. Especially for higher
#' values of \code{d}, the \code{C++} version is faster.
#'
#' @param seed Integer seed value for \link{set.seed} that is used for the
#' approximate computation. Can be used to verify that the \code{C++} and the
#' \code{R} methods give the same results.
#'
#' @details The computation is semi-exact (if \code{exact=TRUE}) also in the 
#' case of higher-dimensional data, under the assumption of general position
#' of the data with respect to the Mahalanobis ellpsoid given by \code{Sigma}
#' and \code{mu}. This is always satisfied if the data is sampled from an 
#' absolutely continous distribution.
#'
#' @return An integer with the value of the (integer) scatter halfspace depth
#' of matrix \code{Sigma} with respect to the dataset \code{X} centred at
#' \code{mu}.
#'
#' @references
#' Mengjie Chen, Chao Gao and Zhao Ren. (2018). Robust covariance and
#' scatter matrix estimation under Huber's contamination model.
#' \emph{The Annals of Statistics}, \bold{46}(5), pp. 1932-1960.
#'
#' Davy Paindaveine and Germain Van Bever. (2018).
#' Halfspace depths for scatter, concentration and shape matrices.
#' \emph{The Annals of Statistics}, \bold{46}(6B), pp. 3276-3307
#'
#' @examples
#' n = 50   # sample size
#' d = 3    # dimension
#' X = matrix(rnorm(n*d), ncol=d) # dataset
#' SHD(X)               # C++ version
#' SHD(X, vrs="R")      # R version, should give the same result
#' SHD(X, method="rpoints")  # random approximation, may give a higher value

SHD = function(X, Sigma = NULL, mu = NULL, 
               method = c("exact","rdirections","rpoints"),
               N = 1e4L, EPS = 1e-14, 
               vrs = c("C", "R"), 
               seed = NULL){
  # computes the exact or approximate scatter halfspace depth of the unit matrix
  # input:
  # X - matrix of dimension n*d, n is the number of observations, d dimension
  # exact - TRUE for exact computation, FALSE for approximate
  # N - number of randomly thrown directions for approximate computation
  #     ignored if exact = TRUE
  # EPS - epsilon, for flopping errors
  # vrs - version of the implemented algorithm, "C", or "R"

  if(!is.null(seed)) set.seed(seed)
  method = match.arg(method)
  vrs = match.arg(vrs)
  RSHD = function(X, mint, inds, EPS=1e-14){

    tangent.directions = function(y){
      # for a vector or matrix y returns a vector of all tangent angles
      # appended by a vector of opposite angles
      # if(!is.matrix(y)) y = matrix(y,nrow=1)
      # if(ncol(y)!=2) stop("Tangent directions are computed only in 2D space")
      R = sqrt(rowSums(y^2))
      valid = (R>=1)
      R[!valid] = NA
      theta = atan2(y[,2],y[,1])
      u = cbind(1/R,sqrt(1-1/R^2))
      uangle = atan2(u[,2],u[,1])
      uangle = c(theta + uangle, theta - uangle)
      uangle = c(uangle,uangle + pi)
      uangle[uangle>pi] = uangle[uangle>pi]-2*pi
      uangle[uangle<= -pi] = uangle[uangle<= -pi]+2*pi
      uangle = sort(uangle)
      mm = length(uangle)
      midangle = c((uangle[-1]+uangle[-mm])/2,
                   (uangle[1]+2*pi+uangle[mm])/2)
      return(midangle[(mm/2+1):(mm)])
    }

    d = ncol(X)
    n = nrow(X)+mint
    # R = apply(X,1,function(x) sqrt(sum(x^2))) # distance
    # valid = (R>1)
    # R = R[valid]
    # m = sum(valid)              # number of points outside the circle
    # if(m<d) return(0)
    Xv = X # X[valid,]
    if(d==2){
      if(!is.null(inds)) warning("In dimension d=2 using version R we 
      always get exact results; method switched to exact.")
      # uangle = tangent.directions(Xv)
      # mm = length(uangle)
      midangle = unique(tangent.directions(Xv))
      #c((uangle[-1]+uangle[-mm])/2,
      #             (uangle[1]+2*pi+uangle[mm])/2)
      U = cbind(cos(midangle),sin(midangle))
      UXa = rowSums(abs(U%*%t(Xv))>1+EPS)
      UXb = rowSums(abs(U%*%t(Xv))<1-EPS)
      UXc = nrow(Xv) - UXa - UXb
      return(min(UXa + UXc, UXb + UXc + mint))
    }
    if(d>=3){
      wrnd = FALSE # not warned yet
      Dpth = Inf # intial (integer) depth
      for(k in (d-1):1){
        tpls = combn(m,k) # all k-tuples of the sample points
        # indices are always in increasing order
        if(is.null(inds)|k==d-1){
          # if is.null(inds) means that random point approximation is applied
          # in that case only k==d-1 is considered
        if(!is.null(inds)) tpls = tpls[,inds,drop=FALSE] 
        # for random method "rpoints"
        ntpls = ncol(tpls)
        if(k>1){
          signs = cbind(1,as.matrix(expand.grid(replicate(k-1, c(-1,1), 
                                                        simplify=FALSE))))
          nsigns = nrow(signs)} else nsigns = 1
        # all combinations of k-1 plus/minus signs
        for(ti in 1:ntpls){
          Y = Xv[tpls[,ti],,drop=FALSE]            # k*d matrix
          # the k=d-1 sample points to determine the "line"
          # (i.e. d-2-dimensional subspace)
          for(si in 1:nsigns){
            # flipping all the signs of the last d-2 points from Y
            # Yl = Y*signs[si,]
            # create the "line" points with flipped signs
            # Yl = Yl[1,]-t(Yl[-1,,drop=FALSE]) # d*(d-2) matrix
            # Yl = cbind(1,diag(d-2))%*%Yl # (d-2)*d matrix
            # Is the same as in the line above transposed but faster
            # vectors determining the "line", i.e.
            # (d-2)-dimensional affine subspace
            if(k==d-1){
              Nullsp = nll(cbind(1,diag(k-1))%*%(Y*signs[si,]),d)
            } else {
              if(k>1){
                N1 = nllfull(Y)[,(k+1):d,drop=FALSE] 
                # last d-k-1 cols of d*d matrix
                # orthogonal complement to the linear span of Y
                N1 = rbind(t(N1),cbind(1,diag(k-1))%*%(Y*signs[si,]))
                Nullsp = nll(N1,d) 
              } else {
                # if k==1
                Nullsp = cbind(c(Y/sqrt(sum(Y^2))),nll(Y,d)[,1])
              }
            }
            # d*2 matrix
            # basis of projection vectors into the 2-dimensional complement to
            # the "line"
            if(ncol(Nullsp)==2){
              # ncol(Nullsp) can be <2 if the space Yl is less than 
              # d-2 dimensional
              # that case is not interesting as it is already covered
              Ylp = Y[1,,drop=FALSE]%*%Nullsp
              # projection of the "line" space into its
              # ortogonal complement given by vectors from N
              if(sum(Ylp^2)>=1){
                # only if the "line" is projected inside the unit sphere
                Xvp = Xv%*%Nullsp         # projected points of X from outside
                # the unit ball into the 2-dimensional space
                U = t(armaDirections(Ylp,EPS)) 
                # 2 vectors of directions onto tangents in the
                # 2-dimensional space of Ylp
                # equivalent with the slower
                # u = tangent.directions(Ylp)
                # U = cbind(cos(u),sin(u))
                nUX = rowSums(abs(UX<-U%*%t(Xvp))>1+EPS)
                # in the 2-dimensional space, in each row a vector of TRUE-FALSE
                # whether the points of Xvp lie outside the slab given by the
                # corresponding vector in a row of U
                #
                mp = rowSums(abs(abs(UX)-1)<EPS)
                # number of points almost on the boundary of the slab
                tempDpth = min(nUX,n-(nUX+mp))
                # temporary depth
                #if(tempDpth<Dpth){
                # for diagnostics
                #  res2 = c(tempDpth,tpls[,ti],signs[si,])
                #}
                Dpth = min(tempDpth, Dpth)
                if(Dpth<0) stop("Depth cannot be smaller than 0, 
                                something wrong")
                if(Dpth==0){
                  return(0)
                }
              }
            }
          }
        }
        }
      }
      return(Dpth)
      # return(res2)
    }
  }

  if(is.vector(X)){
    X = matrix(X,ncol=1)
    warning("Data is assumed to be one-dimensional, coerced to a matrix")
  }
  #
  if(!is.matrix(X)) stop("The data must be a matrix of dimensions n*d")
  d = ncol(X)
  n = nrow(X)
  if(is.null(Sigma)) Sigma = diag(d)
  if(is.null(mu)) mu = rep(0,d)
  if(N == Inf) method = "exact"
  # Transform the data so that it is enough to compute the depth of the unit
  # matrix centred at the origin
  ESigma = eigen(Sigma) # eigendecomposition of Sigma
  if(any(ESigma$values < EPS)) stop("Matrix Sigma is numerically singular")
  Sinv = ESigma$vectors%*%diag(ESigma$values^(-1/2))%*%t(ESigma$vectors)
  X = X - matrix(rep(mu,n),ncol=d,byrow=TRUE) # centering
  X = X%*%Sinv # scaling
  #
  if(d==1){
    # if the data is one-dimensional
    n.out = sum(abs(X) >= 1)
    n.in = sum(abs(X) <= 1)
    return(min(n.in, n.out))
  }
  #
  if(EPS<0) stop("EPS must be positive")
  if((N<0)|(!is.numeric(N))) stop("N must be a positive integer")
  if(method=="exact") N = 0L
  if((d>5)&(method=="exact")&(vrs=="C")){
    warning("exact C version currently implemented only for d<=5,
            switching to the R version")
    vrs = "R"
  }
  #
  R = apply(X,1,function(x) sqrt(sum(x^2))) # distance
  valid = (R>1)
  m = sum(valid)              # number of points outside the circle
  if(m<d) return(0)
  Xv = X[valid,]
  # C version of the code, always if method=="rdirections"
  if(method=="rdirections"){
    return(armaCSHDrandom(Xv,n-m,N,EPS))
  }
  if(method=="exact"){
    if(vrs=="C") return(armaCSHD(Xv,n-m,EPS))
    if(vrs=="R") return(RSHD(Xv,n-m,NULL,EPS))
  }
  if(method=="rpoints"){
    matinds = replicate(N,sample(m,d-1))-1 # lower by 1 for C++
    if(is.null(dim(matinds))) matinds = matrix(matinds,nrow=1)
    matinds = t(unique(t(matinds)))
    return(armaCSHDrpoints(Xv,n-m,matinds,EPS))
    # if(vrs=="R") return(RSHD(Xv,n-m,inds,EPS))
  }
}