# include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

// Stanislav Nagy
// nagy@karlin.mff.cuni.cz
// 06.08.2022 
//

// using namespace Rcpp;   // for Rcout

// [[Rcpp::export()]]
double projdist (arma::mat x){
// distance of an affine subspace given by the points in the rows of X
// to the origin
  double res;
  int n = x.n_rows;
  arma::mat rhs(n,1);
  rhs.ones();
  res = 1/accu(solve(x * trans(x), rhs));
  return(res);
}

// [[Rcpp::export()]]
arma::mat nllfull (arma::mat X){
// faster Null function from MASS package
// input: matrix X (m*d)
// output: full matrix Q in the QR decomposition
  arma::mat Q, R;
  arma::qr(Q,R,trans(X));
  return(Q);
}

// [[Rcpp::export()]]
arma::mat nll (arma::mat X, int d){
// faster Null function from MASS package
// input: matrix X (m*d)
// output: last two columns of matrix Q in the QR decomposition
  arma::mat Q, R;
  arma::qr(Q,R,trans(X));
  // int r = arma::rank(X);
  // Rcout << "r: " << r << std::endl;
  // if(r!=d-2) Rcpp::warning("Warning: Points are not in general position, computation does not have to be exact.");
  // if(r<d){
  return(Q.cols(d-2,d-1));
  // in general we need d-k-1 columns of the orthogonal complement
  // to complement the k-1 dimensional affine hull of points (this gives d-k-1 + k-1 = d-2)
  // for k = 1 this gives d-2. But the case k=1 is handled differently
  // for k = 2 this gives d-3, which is for d=5 equal to 2. 
  // So, for d<=5, two vectors of the output are enough.
  //  } else return(Q);
}

// [[Rcpp::export]]
arma::mat armaDirections(arma::mat x, double EPS){
// x is a vector of two coordinates
// result is transposed compared to the result of the R code directions()

  arma::mat res(2,2);
  // 2*2 matrix {r[1,1],r[2,1],r[1,2],r[2,2]}
  double a = 0;
  double b = 0;
  double c = 0;

  a = x(0)*x(0)+x(1)*x(1);
  if(abs(x(0)) > EPS){
    b = -2 * x(1);
    c = 1 - x(0)*x(0);
    res(1,0) = (-b + sqrt(b * b - 4 * a * c)) / (2 * a);
    res(0,0) = (1 - x(1) * res(1,0)) / x(0);
    res(1,1) = (-b - sqrt(b * b - 4 * a * c)) / (2 * a);
    res(0,1) = (1 - x(1) * res(1,1)) / x(0);
  } else {
    b = -2 * x(0);
    c = 1 - x(1) * x(1);
    res(0,0) = (-b + sqrt(b * b - 4 * a * c)) / (2 * a);
    res(1,0) = (1 - x(0) * res(0,0)) / x(1);
    res(0,1) = (-b - sqrt(b * b - 4 * a * c)) / (2 * a);
    res(1,1) = (1 - x(0) * res(1,0)) / x(1);
  }
  return(res);
}

int evalU(arma::mat U, int mint, double EPS){
// evaluate the U matrix in CSHD
  arma::umat bigr = U > 1+EPS, smlr = U < 1-EPS;
  arma::mat nbigr = arma::conv_to<arma::mat>::from(bigr);
  arma::mat nsmlr = arma::conv_to<arma::mat>::from(smlr);
  arma::mat sbigr = sum(nbigr), ssmlr = sum(nsmlr)+mint;
  int tempin = ssmlr.min(), tempout = sbigr.min();
  if(tempin<=tempout){
    return(tempin); 
    } else return(tempout);
}

// [[Rcpp::export]]
int armaCSHDrandom(arma::mat X, int mint, int N, double EPS){
// N number of randomly thrown directions
// mint number of points in the unit ball
  int n = X.n_rows;
  int d = X.n_cols;
  int res = n+1, tempin, tempout;
  // NumericVector res2(d+1);
  arma::mat u(d,N,arma::fill::randn);  // random directions
  arma::mat U(n,N);
  
  // matrix of all random directions
  for(int j = 0; j<N; j++){
    u.col(j) = u.col(j)/norm(u.col(j));
  }
  // matrix multiplication
  U = X * u;
  for(int j = 0; j < N; j++){
    tempin = mint;
    tempout = 0;
    for(int k = 0; k < n; k++){
      if(abs(U(k,j))>1+EPS) tempout++;
      if(abs(U(k,j))<1-EPS) tempin++;
      }
    if(tempin<res){
      res = tempin;
      }
    if(tempout<res){
      res = tempout;
      }
    if(res == 0) return(res);
    }
  return(res);
}

// [[Rcpp::export]]
int armaCSHDrpoints(arma::mat X, int mint, arma::mat inds, double EPS){
  int n = X.n_rows, d = X.n_cols, N = inds.n_cols;
  arma::mat dirs(2,2), U(n,2);
  int res = n+1, temp = 0;
  // random approximation, only full intersections are considered
  // that is, only intersections of d-1 (anti-)circles are taken

  if(d>5) Rcpp::stop("This implementation works only for d<=5.");
  //
  // d == 2
  //
  if(d==2){
  for(int ii = 0; ii < N; ii++){
    dirs = armaDirections(X.row(inds(0,ii)),EPS);
    U = abs(X*dirs);
    temp = evalU(U, mint, EPS);
    if(temp<res) res = temp;
    if(res == 0) return(res);
    }
  }
  //
  // d == 3
  //
  if(d==3){
    arma::mat u(d-2,d);
    arma::mat P(d,2);
    arma::mat XP(n,2);
    //
    for(int ii = 0; ii < N; ii++){
      int i = inds(0,ii), j = inds(1,ii);
      for(int sg = 0; sg<2; sg++){
        if(sg==0){
          u.row(0) = X.row(i) - X.row(j);
          } else {
          u.row(0) = X.row(i) + X.row(j);  // line
          }
        P = nll(u,d); // projection matrix to the orthogonal complement
        XP = X * P;  // projected dataset into the orthogonal plane
        if(norm(XP.row(i))>=1.0){
          dirs = armaDirections(XP.row(i),EPS);
          U = abs(XP*dirs);
          temp = evalU(U, mint, EPS);
          if(temp<res) res = temp;
          if(res == 0) return(res);
        }                        
      }
    }
  }
  //
  // d == 4
  //
  if(d==4){
    arma::mat u(2,d);
    arma::mat P(d,2);
    arma::mat XP(n,2);
    for(int ii = 0; ii < N; ii++){
      int i = inds(0,ii), j = inds(1,ii), k = inds(2,ii);
      for(int sgj = 0; sgj<2; sgj++){
        for(int sgk = 0; sgk<2; sgk++){
          if(sgj==0){
            u.row(0) = X.row(i) - X.row(j);  // first line, circle
            } else {
            u.row(0) = X.row(i) + X.row(j);  // first line, anti-circle
          }
          if(sgk==0){
            u.row(1) = X.row(i) - X.row(k); // second line, circle
            } else {
            u.row(1) = X.row(i) + X.row(k); // second line, anti-circle
          }
          P = nll(u,d); // projection matrix to the orthogonal complement
          XP = X * P;  // projected dataset into the orthogonal plane
          if(norm(XP.row(i))>=1.0){
            // if the projection of the line is outside the projected circle
            dirs = armaDirections(XP.row(i),EPS);
            U = abs(XP*dirs);
            temp = evalU(U, mint, EPS);
            if(temp<res) res = temp;
            if(res == 0) return(res);
          }         
        }
      }
    }
  }
  //
  // d == 5
  //
  if(d==5){
    arma::mat u2(2,d);
    arma::mat u(3,d);
    arma::mat P(d,2);
    arma::mat XP(n,2);
    //
    for(int ii = 0; ii < N; ii++){
      int i = inds(0,ii), j = inds(1,ii), k = inds(2,ii), l = inds(3,ii);
      for(int sgj = 0; sgj<2; sgj++){
        for(int sgk = 0; sgk<2; sgk++){
          for(int sgl = 0; sgl<2; sgl++){
            if(sgj==0){
              u.row(0) = X.row(i) - X.row(j);  // first line
              } else {
              u.row(0) = X.row(i) + X.row(j);
            }
            if(sgk==0){
              u.row(1) = X.row(i) - X.row(k); // second line
              } else {
              u.row(1) = X.row(i) + X.row(k);
            }
            if(sgl==0){
              u.row(2) = X.row(i) - X.row(l); // third line
              } else {
              u.row(2) = X.row(i) + X.row(l);
            }
            P = nll(u,d); // projection matrix to the orthogonal complement
            XP = X * P;  // projected dataset into the orthogonal plane
            if(norm(XP.row(i))>=1.0){
              dirs = armaDirections(XP.row(i),EPS);
              U = abs(XP*dirs);
              temp = evalU(U, mint, EPS);
              if(temp<res) res = temp;
              if(res == 0) return(res);
            }
          }
        }         
      }
    }
  }
  return(res);
}

// [[Rcpp::export]]
int armaCSHD(arma::mat X, int mint, double EPS){
  int n = X.n_rows, d = X.n_cols;
  arma::mat dirs(2,2), U(n,2);
  int res = n+1, temp = 0;

  if(d>5) Rcpp::stop("This implementation works only for d<=5.");
  //
  // d == 2
  //
  if(d==2){
  for(int i = 0; i < n; i++){
    dirs = armaDirections(X.row(i),EPS);
    U = abs(X*dirs);
    temp = evalU(U, mint, EPS);
    if(temp<res) res = temp;
    if(res == 0) return(res);
    }
  }
  //
  // d == 3
  //
  if(d==3){
    arma::mat u(d-2,d);
    arma::mat P(d,2);
    arma::mat XP(n,2);
    Rcpp::LogicalVector usd(n);
    //
    usd.fill(false); // indicator whether the circle of Xi was already intersected
    for(int i = 0; i < n-1; i++){
      for(int j = i+1; j < n; j++){
        for(int sg = 0; sg<2; sg++){
          if(sg==0){
            u.row(0) = X.row(i) - X.row(j);
            } else {
            u.row(0) = X.row(i) + X.row(j);  // line
            }
          P = nll(u,d); // projection matrix to the orthogonal complement
          XP = X * P;  // projected dataset into the orthogonal plane
          if(norm(XP.row(i))>=1.0){
            usd[i] = true;
            usd[j] = true;
            dirs = armaDirections(XP.row(i),EPS);
            U = abs(XP*dirs);
            temp = evalU(U, mint, EPS);
            if(temp<res) res = temp;
            if(res == 0) return(res);
          }                        
        }
      }
    } 
    // final loop over values that were not intersected
    for(int i=0; i<n; i++){
      if(!(usd[i])){
      P.col(0) = trans(X.row(i)/norm(X.row(i)));  // take each point outside the ball and normalize it
      u.row(0) = X.row(i);
      P.col(1) = nll(u,d).col(0); // complement it with any orthogonal unit length vector
      XP = X * P;           // project to the 2D space
      dirs = armaDirections(XP.row(i),EPS);
      U = abs(XP*dirs);
      temp = evalU(U, mint, EPS);
      if(temp<res) res = temp;
      if(res == 0) return(res);
      }
    }
  }
  //
  // d == 4
  //
  if(d==4){
    arma::mat u(2,d);
    arma::mat P(d,2);
    arma::mat XP(n,2);
    arma::mat usd(2*n,2*n,arma::fill::zeros); 
    // indicators whether indicex were already used
    // we use only the upper triangle of the matrix, that is
    // for i,j=1,...,n
    // elements usd(i,j) with i<=j
    // usd(i,i) = TRUE means that i-th circle was not intersected
    // usd(i,j) = TRUE means that the intersection of i-th and j-th circle was intersected
    // for i,j=n+1,...,2*n stand for the anti-circles
    //
    // usd(i,j+n) with i<=j stands for circle of i and anti-circle of j
    //
    for(int i = 0; i < n-2; i++){
      for(int j = i+1; j < n-1; j++){
        for(int k = j+1; k < n; k++ ){
          for(int sgj = 0; sgj<2; sgj++){
            for(int sgk = 0; sgk<2; sgk++){
              if(sgj==0){
                u.row(0) = X.row(i) - X.row(j);  // first line, circle
                } else {
                u.row(0) = X.row(i) + X.row(j);  // first line, anti-circle
                }
              if(sgk==0){
                u.row(1) = X.row(i) - X.row(k); // second line, circle
                } else {
                u.row(1) = X.row(i) + X.row(k); // second line, anti-circle
                }
              P = nll(u,d); // projection matrix to the orthogonal complement
              XP = X * P;  // projected dataset into the orthogonal plane
              if(norm(XP.row(i))>=1.0){
                // if the projection of the line is outside the projected circle
                usd(i,i) = 1;  // circle i visited
                usd(j,j) = 1;  // circle j visited
                usd(k,k) = 1;  // circle k visited
                usd(i,j+sgj*n) = 1; // circle i and (anti-)circle j visited
                usd(i,k+sgk*n) = 1; // circle i and (anti-)circle k visited
                usd(j,k+abs(sgj-sgk)*n) = 1; // circle j and k visited OR circle j and anti-circle k visited
                // sgj sgk abs(sgj-sgk) result
                //   0   0   0          C-C
                //   0   1   1          C-A
                //   1   0   1          C-A
                //   1   1   0          C-C
                dirs = armaDirections(XP.row(i),EPS);
                U = abs(XP*dirs);
                temp = evalU(U, mint, EPS);
                if(temp<res) res = temp;
                if(res == 0) return(res);
              }         
            }
          }
        }
      }
    }
    // final loops over values that were not intersected, double circles
    for(int i=0; i<n-1; i++){
      for(int j=i+1; j<n; j++){
        if(usd(i,j)+usd(i,j+n)<2-EPS){
          // if the circles i j didn't intersect or circles i -j didn't intersect th thir (anti-) circle
          // i j res
          // 0 0 TRUE
          // 1 0 TRUE
          // 0 1 TRUE
          // 1 1 FALSE
          u.row(0) = X.row(i);
          u.row(1) = X.row(j);
          u.row(0) = trans(nll(u,d).col(0));  // first vector is orthogonal to the linear span of i and j
          for(int sg = 0; sg<2; sg++){
            if(usd(i,j+sg*n)<EPS){ // if circle i and (anti-)circle j were not intersected by a third one
              // we already found that i and +-j do not have any intersection with a third circle
              // now we must find whether i and +-j have a common intersection
              if(sg==0){ // circle i may intersect with circle j
                u.row(1) = X.row(i)-X.row(j);  // take a vector of  the line
                } else { // circle i may intersect with anti-circle j
                u.row(1) = X.row(i)+X.row(j);  // take a vector of  the line
                } // second vector is the direction in the affine hull of i and j           
              P = nll(u,d);
              XP = X * P;           // project to the 2D space
              if(norm(XP.row(i))>=1.0){
                usd(i,i) = 1;
                usd(j,j) = 1;  // circles i and j were already intersected
                dirs = armaDirections(XP.row(i),EPS);
                U = abs(XP*dirs);
                temp = evalU(U, mint, EPS);
                if(temp<res) res = temp;
                if(res == 0){
                  return(res);
                }
              }
            }
          }
        }
      }
    }
    // final loops over values that were not intersected, single circle
    for(int i=0; i<n; i++){
      if(usd(i,i)<EPS){ // if circle i was never intersected
        P.col(0) = trans(X.row(i)/norm(X.row(i)));  // take the point outside the ball and normalize it
        P.col(1) = nll(X.row(i),d).col(0); // complement it with any orthogonal unit length vector
        XP = X * P;           // project to the 2D space
        dirs = armaDirections(XP.row(i),EPS);
        U = abs(XP*dirs);
        temp = evalU(U, mint, EPS);
        if(temp<res) res = temp;
        if(res == 0){
          // Rcout << "index: " << i << std::endl;
          return(res);
        }        
      }
    } 
  }
  //
  // d == 5
  //
  if(d==5){
    arma::mat u2(2,d);
    arma::mat u(3,d);
    arma::mat P(d,2);
    arma::mat XP(n,2);
    arma::cube usd(2*n,2*n,2*n,arma::fill::zeros); 
    // indicators whether indices were already used
    //
    for(int i = 0; i < n-3; i++){
      for(int j = i+1; j < n-2; j++){
        for(int k = j+1; k < n-1; k++){
          for(int l = k+1; l < n; l++){
            for(int sgj = 0; sgj<2; sgj++){
              for(int sgk = 0; sgk<2; sgk++){
                for(int sgl = 0; sgl<2; sgl++){
                  if(sgj==0){
                    u.row(0) = X.row(i) - X.row(j);  // first line
                    } else {
                    u.row(0) = X.row(i) + X.row(j);
                    }
                  if(sgk==0){
                    u.row(1) = X.row(i) - X.row(k); // second line
                    } else {
                    u.row(1) = X.row(i) + X.row(k);
                    }
                  if(sgl==0){
                    u.row(2) = X.row(i) - X.row(l); // third line
                    } else {
                    u.row(2) = X.row(i) + X.row(l);
                    }
                  P = nll(u,d); // projection matrix to the orthogonal complement
                  XP = X * P;  // projected dataset into the orthogonal plane
                  if(norm(XP.row(i))>=1.0){
                    // if the projection of the line is outside the projected circle
                  usd(i,i,i) = 1;
                  usd(j,j,j) = 1;
                  usd(k,k,k) = 1;
                  usd(l,l,l) = 1; // circle l was intersected
                  usd(i,i,j+sgj*n) = 1; // circle i and (anti-)circle j were intersected
                  usd(i,i,k+sgk*n) = 1;
                  usd(i,i,l+sgl*n) = 1;
                  usd(j,j,k+abs(sgj-sgk)*n) = 1;
                  usd(j,j,l+abs(sgj-sgl)*n) = 1;
                  usd(k,k,l+abs(sgk-sgl)*n) = 1;
                  usd(i,j+sgj*n,k+sgk*n) = 1;
                  usd(i,j+sgj*n,l+sgl*n) = 1; 
                  usd(i,k+sgk*n,l+sgl*n) = 1;
                  usd(j,k+abs(sgj-sgk)*n,l+abs(sgj-sgl)*n) = 1; 
                  // sgj sgk sgl  | abs(sgj-sgk) abs(sgj-sgl) result
                  //   0   0   0  |  0            0           C-C-C
                  //   0   0   1  |  0            1           C-C-A
                  //   0   1   0  |  1            0           C-A-C
                  //   1   0   0  |  1            1           C-A-A
                  //   1   1   0  |  0            1           C-C-A
                  //   1   0   1  |  1            0           C-A-C
                  //   0   1   1  |  1            1           C-A-A
                  //   1   1   1  |  0            0           C-C-C
                  dirs = armaDirections(XP.row(i),EPS);
                  U = abs(XP*dirs);
                  temp = evalU(U, mint, EPS);
                  if(temp<res) res = temp;
                  if(res == 0) return(res);
                  }
                }
              }         
            }
          }
        }
      }
    }
    // final loops over values that were not intersected, triple circles
    for(int i=0; i<n-2; i++){
      for(int j=i+1; j<n-1; j++){
        for(int k=j+1; k<n; k++){
          if(usd(i,j,k)+usd(i,j+n,k)+usd(i,j,k+n)+usd(i,j+n,k+n)<4-EPS){ 
          // if a combination of (anti-)circles i,j,k was not intersected by a fourth one
            u.row(0) = X.row(i);
            u.row(1) = X.row(j);
            u.row(2) = X.row(k);
            u.row(0) = trans(nll(u,d).col(0));  // first vector is orthogonal to the linear span of i and j and k
            for(int sgj = 0; sgj<2; sgj++){
              for(int sgk = 0; sgk<2; sgk++){
                if(usd(i,j+sgj*n,k+sgk*n)<EPS){
                // if the combination i +-j +-k was not intersected by a fourth one
                  if(sgj==0){
                    u.row(1) = X.row(i) - X.row(j);  // first line
                    } else {
                    u.row(1) = X.row(i) + X.row(j);
                  }
                  if(sgk==0){
                    u.row(2) = X.row(i) - X.row(k); // second line
                    } else {
                    u.row(2) = X.row(i) + X.row(k);
                  } // second and third vectors are in the affine hull of i j k
                  P = nll(u,d);
                  XP = X * P;           // project to the 2D space
                  if(norm(XP.row(i))>=1.0){
                    usd(i,i,i) = 1;
                    usd(j,j,j) = 1;  
                    usd(k,k,k) = 1; // circles i j k were already intersected
                    usd(i,i,j+sgj*n) = 1;
                    usd(i,i,k+sgk*n) = 1;
                    usd(j,j,k+abs(sgj-sgk)*n) = 1; // circles ij, ik, jk were already intersected
                    dirs = armaDirections(XP.row(i),EPS);
                    U = abs(XP*dirs);
                    temp = evalU(U, mint, EPS);
                    if(temp<res) res = temp;
                    if(res == 0) return(res);
                  }
                }
              }
            }
          }
        }
      }
    }
    // final loops over values that were not intersected, double circles
    for(int i=0; i<n-1; i++){
      for(int j=i+1; j<n; j++){
        if(usd(i,i,j)+usd(i,i,j+n)<2-EPS){ 
          // if a combination of (anti-)circles i,j was not intersected by a third one
          u2.row(0) = X.row(i);
          u2.row(1) = X.row(j);
          u.rows(0,1) = trans(nll(u2,d).cols(0,1));
          for(int sgj = 0; sgj<2; sgj++){
            if(usd(i,i,j+sgj*n)<EPS){ // if circles i and +-j were not intersected by a third one
              if(sgj==0){
                u.row(2) = X.row(i) - X.row(j);  // first line
                } else {
                u.row(2) = X.row(i) + X.row(j);
              }          
              P = nll(u,d);
              XP = X * P;           // project to the 2D space
              if(norm(XP.row(i))>=1.0){        
                usd(i,i,i) = 1;
                usd(j,j,j) = 1; // circles i j were already visited
                dirs = armaDirections(XP.row(i),EPS);
                U = abs(XP*dirs);
                temp = evalU(U, mint, EPS);
                if(temp<res) res = temp;
                if(res == 0) return(res);
              }
            }
          }
        }
      }
    }
    // final loops over values that were not intersected, single circle
    for(int i=0; i<n; i++){
      if(usd(i,i,i)<EPS){ // if circle i was never intersected
        P.col(0) = trans(X.row(i)/norm(X.row(i)));  // take the point outside the ball and normalize it
        P.col(1) = nll(X.row(i),d).col(0); // complement it with any orthogonal unit length vector
        XP = X * P;           // project to the 2D space
        dirs = armaDirections(XP.row(i),EPS);
        U = abs(XP*dirs);
        temp = evalU(U, mint, EPS);
        if(temp<res) res = temp;
        if(res == 0) return(res);
      }
    }
  }
  return(res);
}
